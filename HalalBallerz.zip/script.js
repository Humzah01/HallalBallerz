// JavaScript to make the header sticky

window.addEventListener("scroll", function () {
    const header = document.querySelector(".sticky-header");

    if (window.pageYOffset > 100) { // You can adjust this value to determine when the header becomes sticky
        header.classList.add("sticky");
    } else {
        header.classList.remove("sticky");
    }
});
